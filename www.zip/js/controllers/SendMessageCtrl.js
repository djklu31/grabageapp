/**
 * Created by kennylu on 3/4/16.
 */
angular.module('starter')

.controller('SendMessageCtrl', function($scope, $http, SessionService, $stateParams) {


  })
